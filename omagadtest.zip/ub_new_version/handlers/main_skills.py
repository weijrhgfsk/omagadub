from config import f_config, Me, trusted_f, black_iris, user_config_js, GlobalStack, victims_file, all_iris, abs_path
from storage.storage import Settings, me_inf, my_illnesses, JsRead, ctimer, cycle_timers
from functions import func
from loader import app

from pyrogram import Client, filters, enums
from pyrogram.types import Message
from datetime import datetime
from bs4 import BeautifulSoup

import asyncio, re, random


### Main skills ###

@app.on_message(filters.text)
async def main_skills(app: Client, msg: Message):
    
    msgt = msg.text
    msgtl = msg.text.lower()
    
    entity = msg.chat.id
    
    if msg.reply_to_message:
        msgr = msg.reply_to_message
        if not msgr or not msgr.text: return
        msgrt = msgr.text
        msgrtl = msgrt.lower()
    
    if msg.from_user and str(msg.from_user.id) in Settings.trusted:
        
        # Заразить
        if f'{Settings.prefix}б' == msgtl.split(' ')[0] and Settings.trusted[str(msg.from_user.id)]['access']['infection']:
            
            minfect = None
            
            if func.msg_check_tattack(msgtl):
                
                uname = '@' + func.tag_get(msgt)
                
                if len(msgt.split(' ')[:3]) == 3:
                    num = msgt.split(' ')[1]
                    if num.isdigit():
                        minfect = f'биоеб {num} {uname}'    
                    else:
                        minfect = f'биоеб {uname}'
                else:
                    minfect = f'биоеб {uname}'
            elif msg.reply_to_message and msgrt.startswith('👨🏻‍🔬 Была проведена операция заражения') \
            or msg.reply_to_message and func.msg_check_tattack(msgrt) and len(msgt.split(' ')) < 3:
                
                if msg.reply_to_message and msgrt.startswith('👨🏻‍🔬 Была проведена операция заражения') \
                and msgr.entities and len(msgr.entities) >= 2:

                    if len(msgr.entities) >= 2 and msgr.entities[1].type == enums.MessageEntityType.TEXT_LINK:
                        url = msgr.entities[1].url
                    
                    uname = '@' + func.tag_get(url)
                elif msg.reply_to_message and func.msg_check_tattack(msgrtl):
                    uname = '@' + func.tag_get(msgrt)
                
                if len(msgt.split(' ')[:2]) == 2:
                    num = msgt.split(' ')[1]
                    if num.isdigit():
                        minfect = f'биоеб {num} {uname}'
                    else:
                        minfect = f'биоеб {uname}'
                else:
                    minfect = f'биоеб {uname}'
            # reply text ирис заражение
            elif msg.reply_to_message and re.findall(r'😎 .+ подвер[гла]+ заражению', msgrtl) and not '👨🏻‍🔬 Была проведена операция заражения' in msgrt and len(msgr.entities) == 2:
                which_reply_msg = msgr
                fid = str(msgr.entities[1].user.id)
                minfect = f'биоеб @{fid}'
            elif [i for i in ['-', '=', '+'] if i in msgtl]:
                minfect = f'биоеб {msgtl.split(" ")[1]}'


            if not minfect:
                return

            if msg.reply_to_message and '👨🏻‍🔬 Была проведена операция заражения' in msgrt:
                await msgr.reply(minfect)
            else:
                await app.send_message(entity, minfect)
            await msg.delete()
    
        # заражает список жертв по реплаю
        if msg.reply_to_message and msgtl.split(' ')[0] == f'{Settings.prefix}зл' and Settings.trusted[str(msg.from_user.id)]['access']['infection']:
            
            num_list = []
            reply = msgr
            
            if GlobalStack.list_zar:
                temp = await app.send_message(entity, '☕️ Заражения ещё не закончены, ожидайте...')
                asyncio.create_task(func.delete_msg([msg, temp], 12))
                return
            
            if reply.entities is not None:
                await msg.delete()
                for arg in msgtl.split():
                    if '-' in arg:
                        ot_do = arg.split('-')
                        
                        try:
                            num_list.extend(str(x) for x in range(int(ot_do[0]), int(ot_do[1]) + 1))
                        except Exception:
                            temp = await app.send_message(entity, 'Пишите цифры от 1 до 50 или диапазон, например 1 5 15-30 47')
                            asyncio.create_task(func.delete_msg(temp, 12))
                            return
                    else:
                        try:
                            num_list.append(arg)
                        except Exception:
                            temp = await app.send_message(entity, 'Пишите цифры от 1 до 50 или диапазон, например 1 5 15-30 47')
                            asyncio.create_task(func.delete_msg(temp, 12))
                            return
                
                del num_list[0]
                
                url_db = []
                last = ''
                
                for line in msgr.text.html.splitlines():
                    tag = re.search(r'(@[\d\w]+|\?user_id=\d+|t\.me/[\w\d]+)', line)
                    if tag:
                        url_db.append(tag[0].replace('?user_id=', '').replace('@', '').replace('t.me/', ''))
                
                num_list = [i for i in num_list if int(i) <= len(url_db)]
                
                if len(num_list) < 1:
                    temp = await app.send_message(entity, 'Пишите цифры от 1 до 50 или диапазон, например 1 5 15-30 47')
                    asyncio.create_task(func.delete_msg(temp, 12))
                    return
                
                if len(num_list) != 0:
                    GlobalStack.list_zar = True
                    for num in num_list:
                        if int(num) > len(url_db):
                            GlobalStack.stop = False
                            return
                        while GlobalStack.stop:
                            await asyncio.sleep(3.5)
                        url = url_db[int(num) -1]
                        minfect = f'биоеб @{url}'
                        await app.send_message(entity, f'биоеб @{url}')
                        
                        await asyncio.sleep(Settings.list_infect_delay)
                    GlobalStack.stop = False
                    GlobalStack.list_zar = False
        
        # изменение задержки заражение по листу
        if re.fullmatch(r'{}зл (\d|\d\.\d)с'.format(re.escape(Settings.prefix)), msgtl):
            delay = str(msgtl.split(' ')[1].replace('с', ''))
            func.edit_cf(f_config, 'user_settings', 'list_infect_delay', delay)
            temp = await msg.reply(f'⏳ Задержка заражений по листу, изменена <b>{Settings.list_infect_delay}</b> > <b>{delay}</b> секунд')
            Settings.refresh(f_config)
            asyncio.create_task(func.delete_msg([msg, temp], 12))
        
        # цикличное заражение рандома
        if re.fullmatch(r'{}з [-=+](| \d+)'.format(re.escape(Settings.prefix)), msgtl) and Settings.trusted[str(msg.from_user.id)]['access']['infection']:
            await msg.delete()
            parts = msgtl.split(' ')
            num = (int(parts[2]) if len(parts) > 2 else 1)
            if num > 99:
                temp = await app.send_message(msg.chat.id, 'Число циклов не должно превышать 99 раз за одно исполение')
                asyncio.create_task(func.delete_msg(temp, 6))
                return
            else:
                if GlobalStack.list_zar:
                    temp = await app.send_message(entity, '☕️ Заражения ещё не закончены, ожидайте...')
                    asyncio.create_task(func.delete_msg(temp, 6))
                    return
                for c in range(num):
                    while GlobalStack.stop:
                        await asyncio.sleep(2)
                    await app.send_message(msg.chat.id, f'биоеб {parts[1]}')
                    await asyncio.sleep(random.randint(2000, 4000) / 1000)
        
        # исцелиться
        if msgtl == f'{Settings.prefix}х' or re.fullmatch(r'(!вак|!хил|!лечись)', msgtl) and msg.from_user.id == Me.me.id:
            await app.send_message(entity, 'биохил')
            await msg.delete()
        
        elif msgtl == 'хилл':
            await app.send_message(msg.chat.id, 'биохил')
            # await func.heal_me(app, msg, iris_id = black_iris)
            await msg.delete()
        
        # моя лаборатория
        if msgtl == f'{Settings.prefix}л' and (Settings.trusted[str(msg.from_user.id)]['access']['lab'] or str(msg.from_user.id) == str(Me.me.id)):
            temp = await app.send_message(entity, 'биолаб')
            await msg.delete()
        
        # силует лаборатории
        elif msgtl == f'{Settings.prefix}фа':
            if Settings.lab_get:
                await msg.delete()
                return
            text = ''
            Settings.lab_get = True
            try_loop = 0
            while True:
                a = False
                cycles = 0
                try_loop += 1
                temp = await app.send_message(black_iris, 'биолаб')
                await temp.delete()
                while True:
                    await asyncio.sleep(1)
                    async for msg_ in app.search_messages(black_iris, limit = 1):
                        msgt_ = msg_.text
                        
                        if str(msg_.from_user.id) == black_iris and '🦠 Информация о вирусе:' in msgt_:
                            completed_pathogen = ''
                            bio_experience = ''
                            bio_resource = ''
                            fever = ''
                            
                            for line in msgt_.split('\n'):
                                line_ = ' '.join(line.split(' ')[:2])
                                if line_ == '🧪 Патогенов:':
                                    completed_pathogen = line
                                elif line_ == '☣️ Био-опыт:':
                                    bio_experience += line
                                elif line_ == '🧬 Био-ресурс:':
                                    bio_resource += line
                                elif line_ == '🥴 У вас горячка':
                                    fever += line
                            
                            text = (
                                f'{completed_pathogen}\n'
                                f'{bio_experience}\n'
                                f'{bio_resource}\n\n'
                                f'{fever}'
                            )
                            
                            await msg_.delete()
                            
                            text = text
                            a = True
                            break
                        
                    if cycles >= 6:
                        await asyncio.sleep(random.randint(1, 4))
                        break
                    cycles += 1
                        
                    if a:
                        break
                if try_loop >= 3:
                    temp = await msg.reply('⌛️ Время ответа от ириса истекло')
                    await asyncio.sleep(8)
                    await temp.delete()
                    await msg.delete()
                    Settings.lab_get = False
                    return
                if a:
                    break
            
            Settings.lab_get = False
            
            if text == '':
                return
            
            temp1 = await msg.reply(text)
            
            asyncio.create_task(func.delete_msg([temp1, msg], 12))
        
        # моя ежа кастом
        if msgtl == f'{Settings.name} жертвы' and Settings.trusted[str(msg.from_user.id)]['access']['victims'] or re.fullmatch(r'(|!|/|\.)мои жертвы', msgtl) and msg.from_user.id == Me.me.id:
            await func.my_victims_food(app, msg, JsRead.js_read, me_inf.victims_food)
        
        # силует моей ежы
        elif msgtl == f'{Settings.prefix}ж':
            await func.my_victims_food(app, msg, JsRead.js_read, me_inf.victims_food, silhouette = True)
        
        # мои болезни кастом
        if msgtl == f'{Settings.name} болезни' or re.fullmatch(r'(|!|/|\.)мои болезни', msgtl) and msg.from_user.id == Me.me.id:
            await func.illness_get(app, msg, my_illnesses.illnesses)
        
        # вирусы в чат
        if msgtl == f'+{Settings.prefix}в':
            await app.send_message(entity, '+Вирусы')
            await msg.delete()
        
        elif msgtl == f'-{Settings.prefix}в':
            await app.send_message(entity, '-Вирусы')
            await msg.delete()
        #
        
        # изменить имя патогена
        if re.fullmatch(r'(\+{}пат [-0-9a-zA-ZА-Яа-я ]+)'.format(re.escape(Settings.prefix)), msgtl):
            msgtspl = ' '.join(msgt.split(' ')[1:])
            await app.send_message(entity, f'+Имя патогена {msgtspl}')
            await msg.delete()
        
        elif msgtl == f'-{Settings.prefix}пат' \
        or msgtl == '-пат' and msg.from_user.id == Me.me.id:
            await app.send_message(entity, '-Имя патогена')
            await msg.delete()
        #
        
        # левелап лаборатории
        if re.fullmatch(r'(\.{}|\.)[патогенрзбксьимул]+ [1-5]'.format(re.escape(Settings.prefix)), msgtl) and (Settings.trusted[str(msg.from_user.id)]['access']['lvl_lab'] or msg.from_user.id == str(Me.me.id)):
            msgtspl = msgt.split(" ")
            # Патоген
            if re.fullmatch(r'(\.{}|\.)патоген [1-5]'.format(re.escape(Settings.prefix)), msgtl):
                await app.send_message(entity, f'++Патоген {msgtspl[1]}')
            # Разработка
            if re.fullmatch(r'(\.{}|\.)разработка [1-5]'.format(re.escape(Settings.prefix)), msgtl):
                await app.send_message(entity, f'++Разработка {msgtspl[1]}')
            # Заразность
            if re.fullmatch(r'(\.{}|\.)заразность [1-5]'.format(re.escape(Settings.prefix)), msgtl):
                await app.send_message(entity, f'++Заразность {msgtspl[1]}')
            # Иммунитет
            if re.fullmatch(r'(\.{}|\.)иммунитет [1-5]'.format(re.escape(Settings.prefix)), msgtl):
                await app.send_message(entity, f'++Иммунитет {msgtspl[1]}')
            # Летальность
            if re.fullmatch(r'(\.{}|\.)летальность [1-5]'.format(re.escape(Settings.prefix)), msgtl):
                await app.send_message(entity, f'++Летальность {msgtspl[1]}')
            # Безопасность
            if re.fullmatch(r'(\.{}|\.)безопасность [1-5]'.format(re.escape(Settings.prefix)), msgtl):
                await app.send_message(entity, f'++Безопасность {msgtspl[1]}')
            
            await msg.delete()
        
        # узнать кто прячется за заражением
        if re.fullmatch(r'кто(| \d+)', msgtl) and msg.reply_to_message and msg.from_user.id == Me.me.id:
            if msgt.split(' ')[-1].isdigit():
                suspects = int(msgt.split(' ')[1])
            else:
                suspects = 3
            msgr = msg.reply_to_message
            msgrt = msgr.text
            find = False
            # find by name of pathogen
            if '🦠 Кто-то подверг заражению' in msgrt and not 'неизвестным патогеном' in msgrt and len(msgt.split('\n')):
                patogen_name = msgrt.rpartition('»')[0].partition('«')[2]
                lethality = re.search(r'\d+ д[янейь]+', msgrt.split('\n')[2])[0]
                users = ''
                async for message in app.search_global(query=f'заражению 🕵️‍♂️ Служба безопасности докладывает "{patogen_name}"'):
                    if message.from_user.id in all_iris and len(message.entities) >= 2:
                        link = func.tag_get(message.entities[1].url)
                        name = message.text.html.splitlines()[2].partition('Организатор заражения: ')[2].rpartition('(')[0][:-1]
                        db_check = await func.check_in_db(app, link, JsRead, victims_file, get_entity = True)
                        if db_check['instance'] and db_check['zar'] == 'True':
                            id = list(db_check['instance'])[0]
                            exp = db_check['instance'][id]['experience']
                            name = db_check['instance'][id]['name']
                            bio_entity = f'<a href="tg://openmessage?user_id={id}">{name}</a>'
                            mesg = (
                                f'✨ Ваша жертва <b>{bio_entity}</b> <b>☣️ +{exp}</b>\n'
                                f'<code>биоеб @{id}</code>'
                            )
                        else:
                            mesg = f'✨ Ваша жертва <code>@{link}</code> <b>{name}</b>'
                        find = True
                        break
            # find suspects by no name pathogen
            elif '🦠 Кто-то подверг заражению' in msgrt and 'неизвестным патогеном' in msgrt:
                lethality = re.search(r'\d+', msgrt.split('\n')[2])[0]
                num = 0
                links = ''
                async for message in app.search_global(limit=suspects, query=f'🕵️‍♂️ Служба безопасности неизвестным патогеном "{lethality}"'):
                    if message.from_user.id in all_iris and len(message.entities) >= 2:
                        link = func.tag_get(message.entities[1].url)
                        name = message.text.html.splitlines()[2].partition('Организатор заражения: ')[2].rpartition('(')[0][:-1]
                        if link not in links:
                            num += 1
                            links += f'{num}. <code>@{link}</code> <i>{name}</i>\n'
                        find = True
                if find:
                    mesg = f'✨ Список подозреваемых жертв:\n{links}'
            else:
                return
            if find:
                temp = await msgr.reply(mesg)
            else:
                angry_word = random.choice(['Пидорас', 'Сучка кудрявая', 'Ебанат', 'Чучело дырявое'])
                temp = await msgr.reply(f'❔ {angry_word} не найден')
            await msg.delete()
            asyncio.create_task(func.delete_msg(temp, 220))
        
        # цтаймеры
        if re.fullmatch(r'\+({}|)цт (\d+|\d+\.\d+) (секун[даы]+|мину[тыау]+|ча[совыа]+) .+'.format(re.escape(Settings.prefix)), msgtl) and (Settings.trusted[str(msg.from_user.id)]['access']['ctimer'] or msg.from_user.id == str(Me.me.id)):
            parts = msgtl.split(' ')
            if parts[0] == '+цт' and msg.from_user.id != Me.me.id:
                return
            time = parts[1]
            time_type = parts[2]
            if re.fullmatch(r'мину[тыау]+', time_type):
                time = float(time) * 60
            elif re.fullmatch(r'секун[даы]+', time_type):
                time = float(time)
            else:
                time = float(time) * 60 * 60
            text = ' '.join(parts[3:])
            chat_id = msg.chat.id
            if re.fullmatch(r'(!-биоигра|-биоигра|бан|мут|дос|\+дов|-дов|дов|.корп участники|.корп|[.]+цт)', text.split(' ')[0].lower()):
                name = Settings.trusted[arg]['name']
                Settings.trusted.pop(arg)
                func.json_write(trusted_f, Settings.trusted)
                Settings.refresh(f_config)
                temp = await msg.forward_to('me')
                text = f'Замечена подозрительная активность от @{msg.from_user.id}\nДоверка была убрана автоматически'
                await temp.reply(text)
                await app.send_message('me', text)
                return
            try:
                title = msg.chat.title
            except:
                title = msg.chat.first_name
            read = func.json_read(user_config_js)
            timer_num = None
            for key in read['cycle_timers']:
                if read['cycle_timers'][key] is None:
                    timer_num = key
                    break
            if timer_num:
                read['cycle_timers'][timer_num] = {'delay': time, 'job': text, 'chat': {'id': chat_id, 'title': title}}
                func.json_write(user_config_js, read)
                ctimer.refresh()

                task = asyncio.create_task(func.cycle_timer(app, time, text, chat_id))
                cycle_timers[timer_num] = task
                temp = await msg.reply(f'✅ Цикличный таймер <b>{timer_num[-1]}</b> добавлен. Он будет работать каждые <i>{parts[1]}</i> {parts[2]}')
            else:
                temp = await msg.reply('Нет доступных таймеров, удалите лишние')
            asyncio.create_task(func.delete_msg([temp, msg], 12))

        elif re.fullmatch(r'-({}|)цт \d+'.format(re.escape(Settings.prefix)), msgtl) and (Settings.trusted[str(msg.from_user.id)]['access']['ctimer'] or msg.from_user.id == str(Me.me.id)):
            parts = msgtl.split(' ')
            if parts[0] == '-цт' and msg.from_user.id != Me.me.id:
                return
            timer_num = parts[1]
            timer_num_ = None
            read = func.json_read(user_config_js)
            for key in read['cycle_timers']:
                if timer_num in key and read['cycle_timers'][key] is not None:
                    timer_num_ = key
                    break
            if timer_num_:
                read['cycle_timers'][timer_num_] = None
                func.json_write(user_config_js, read)
                cycle_timers[timer_num_].cancel()
                del cycle_timers[timer_num_]
                ctimer.refresh()
                temp = await msg.reply(f'Цикличный таймер <b>«{timer_num_[-1]}»</b> удален')
            else:
                temp = await msg.reply('Такого таймера не существует')
            asyncio.create_task(func.delete_msg([temp, msg], 12))

        # __me zone__
        if msg.from_user.id == Me.me.id:
            if re.fullmatch(r'!сб( \d+|)', msgtl):
                parts = msgt.split(' ')
                if len(parts) == 1:
                    number = 10
                else:
                    number = int(parts[1])
                number_ = number
                victims = {}
                udbs = []
                text = f'✨ Fresh <b>{number}</b> illness in this chat:\n'
                async for mesg in app.search_messages(msg.chat.id, query = '🕵️‍♂️ Служба безопасности лаборатории докладывает:'):
                    if mesg.entities and len(mesg.entities) >= 2 and mesg.entities[1].type == enums.MessageEntityType.TEXT_LINK:
                        link = func.tag_get(mesg.entities[1].url)
                        name = re.split(r'(Организатор заражения: |\n)', mesg.text.splitlines()[2])[2]
                        exp = '🔸'
                        if link not in udbs:
                            udbs.append(link)
                            id_enemy = link
                            db_check = await func.check_in_db(app, link, JsRead, victims_file, get_entity = (False if Settings.call_api else True), need_name = False)
                            if db_check['instance']:
                                id_enemy = list(db_check['instance'])[0]
                                if db_check['zar'] != 'False':
                                    exp = db_check['instance'][id_enemy]['experience']
                            if id_enemy not in victims:
                                victims[id_enemy] = {'name': name, 'exp': exp}
                                number_ -= 1
                                name = ''
                    if number_ == 0:
                        break
                for num, (key, val) in enumerate(victims.items(), 1):
                    victim_entity = f'<a href="tg://openmessage?user_id={key}">{val["name"]}</a>'
                    text += f'{num}. {victim_entity} <code>биоеб @{key}</code> <i>{val["exp"]}</i> \n'
                if number > 50:
                    dnow = datetime.now().strftime('%H:%M:%S')
                    temp_file_victims = f'{abs_path}/data/settings/temp_victimers-{dnow}.txt'
                    with open(temp_file_victims, 'w') as f:
                        f.write(BeautifulSoup(text, 'html.parser').get_text())
                    temp = await msg.reply_document(temp_file_victims, file_name = f'свежие-{number}-жертв')
                    os.remove(temp_file_victims)
                else:
                    temp = await msg.reply(text, quote = False, disable_web_page_preview = True)
                await msg.delete()
                asyncio.create_task(func.delete_msg([temp, msg], 120))




# trusted
@app.on_message(filters.text, group = 1)
async def trusted(app: Client, msg: Message):
    
    msgt = msg.text
    msgtl = msgt.lower()
    
    name = None
    
    if msg.from_user and str(msg.from_user.id) in Settings.trusted:
    
        if msgtl.split(' ')[0] == '+дов' and msg.from_user.id == Me.me.id or msgtl.split(' ')[0] == f'+{Settings.prefix}дов' and Settings.trusted[str(msg.from_user.id)]['access']['dov']:
            if msg.reply_to_message and '@' not in msgt:
                msgr = msg.reply_to_message
                arg = str(msgr.from_user.id)
                name = msgr.from_user.first_name
            elif not msg.reply_to_message and '@' in msgt:
                arg = msgtl.split('@')[1]
            else:
                return
            if re.fullmatch(r'[-\d]+', arg):
                if arg in Settings.trusted:
                    message = f'Довереность > <a href="tg://openmessage?user_id={arg}">{Settings.trusted[arg]["name"]}</a> уже существует'
                else:
                    if name is None:
                        db_check = await func.check_in_db(app, arg, JsRead, victims_file, get_entity = True, iris_id = black_iris)
                        if db_check['instance']:
                            name = db_check['instance'][arg]['name']
                        else:
                            name = arg
                    func.add_trusted(arg, Settings.trusted, trusted_f, name = name)
                    Settings.refresh(f_config)
                    bio_entity = f'<a href="tg://openmessage?user_id={arg}">{Settings.trusted[arg]["name"]}</a>'
                    message = f'Довереность на {bio_entity} добавлена'
                temp = await app.send_message(msg.chat.id, message)
                await msg.delete()
        
        if msgtl.split(' ')[0] == '-дов' and msg.from_user.id == Me.me.id or msgtl.split(' ')[0] == f'-{Settings.prefix}дов' and Settings.trusted[str(msg.from_user.id)]['access']['dov']:
            if msg.reply_to_message and '@' not in msgt:
                msgr = msg.reply_to_message
                arg = str(msgr.from_user.id)
            elif not msg.reply_to_message and '@' in msgt:
                arg = msgtl.split('@')[1]
            else:
                return
            if re.fullmatch(r'[-\d]+', arg):
                if arg == str(Me.me.id):
                    temp = await msg.reply('❗️ Нельзя убрать у самого себя доверенность')
                    asyncio.create_task(func.delete_msg([msg, temp], 15))
                    return
                
                if arg in Settings.trusted:
                    name = Settings.trusted[arg]['name']
                    Settings.trusted.pop(arg)
                    func.json_write(trusted_f, Settings.trusted)
                    Settings.refresh(f_config)
                    bio_entity = f'<a href="tg://openmessage?user_id={arg}">{name}</a>'
                    message = f'❌ Довереность на {bio_entity} удалена'
                else:
                    message = f'❔ Довереность на <code>.ид @{arg}</code> не найдена'
                temp = await app.send_message(msg.chat.id, message)
                await msg.delete()
        
        # Access
        if msg.from_user.id == Me.me.id and re.fullmatch(r'дос (лаб|аплаб|ежа|цт|дов|вампир|где|зар)(\s@\d+|)', msgtl):
            read = Settings.trusted
            val = False
            parts = msgtl.split(' ')
            if parts[1] == 'лаб':
                prefix = 'lab'
            elif parts[1] == 'аплаб':
                prefix = 'lvl_lab'
            elif parts[1] == 'ежа':
                prefix = 'victims'
            elif parts[1] == 'цт':
                prefix = 'ctimer'
            elif parts[1] == 'дов':
                prefix = 'dov'
            elif parts[1] == 'вампир':
                prefix = 'vampir'
            elif parts[1] == 'где':
                prefix = 'where_trigger'
            elif parts[1] == 'зар':
                prefix = 'infection'
            else:
                return
            if '@' in msgt and not msg.reply_to_message or msg.reply_to_message:
                if msg.reply_to_message and '@' not in msgt:
                    msgr = msg.reply_to_message
                    id = str(msgr.from_user.id)
                else:
                    id = func.tag_get(msgt)
                
                if id in read:
                    bio_entity = f'<a href="tg://openmessage?user_id={id}">{Settings.trusted[id]["name"]}</a>'
                    if read[id]['access'][prefix]:
                        read[id]['access'][prefix] = False
                        text = f'🔒 Доступ к {parts[1]} успешно отключен для {bio_entity}'
                    else:
                        read[id]['access'][prefix] = True
                        text = f'🔓 Доступ к {parts[1]} успешно включен для {bio_entity}'
                else:
                    text = f'❔ Доверенность на <code>ид @{id}</code> не найдена'
            else:
                text = f'🔒 Доступ к {parts[1]} успешно отключен для всех'
                if not any([val['access'][prefix] for val in read.values()]):
                    val = True
                    text = f'🔓 Доступ к {parts[1]} успешно включен для всех'
                for key in read:
                    read[key]['access'][prefix] = val
            func.json_write(trusted_f, read)
            Settings.refresh(f_config)
            
            temp = await msg.reply(text)
            asyncio.create_task(func.delete_msg([temp, msg], 12))
    

