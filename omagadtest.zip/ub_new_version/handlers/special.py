from config import f_config, Me, abs_path, victims_file, where_triggers_cute, where_triggers_evil, Style
from storage.storage import Settings, JsRead
from bs4 import BeautifulSoup
from datetime import datetime
from functions import func
from loader import app

from pyrogram.raw.functions.messages import SendReaction
from pyrogram.raw.types import InputPeerSelf, ReactionCustomEmoji
from pyrogram import Client, filters, enums
from pyrogram.types import Message

import asyncio, re, random, requests, os, json, pickle

@app.on_message(filters.text, group = 7)
async def special(app: Client, msg: Message):
    
    msgt = msg.text
    msgtl = (msg.text.lower() if msg.text else '')
    entity = msg.chat.id
    
    if msg.reply_to_message:
        msgr = msg.reply_to_message
        if not msgr or not msgr.text: return
        msgrt = msgr.text
        msgrtl = msgrt.lower()
    
    ### trusted zone ###
    if msg.from_user and str(msg.from_user.id) in Settings.trusted:
        # где я
        if msgtl == f'где {Settings.name}' and (Settings.trusted[str(msg.from_user.id)]['access']['where_trigger'] or msg.from_user.id == str(Me.me.id)):
            if Settings.where_mode == 'милый':
                answer = random.choice(where_triggers_cute)
            if Settings.where_mode == 'грубый':
                answer = random.choice(where_triggers_evil)
            if Settings.where_mode == 'рандом':
                answer = random.choice(where_triggers_evil + where_triggers_cute)
            
            if answer[-4:] == '.gif':
                await msg.reply_animation(answer, quote = True)
            else:
                await msg.reply(answer)
    
    
    ### me zone ###
    if msg.from_user and msg.from_user.id == Me.me.id:
        
        # if msgtl == 'e' and msg.reply_to_message:
        #     await msg.edit('\n'.join(['<code>'+str(i)+'</code>' for i in msgr.entities]))
        
        # if msgtl == 't' and msg.reply_to_message:
        #     await msg.edit(msgr.text.html, parse_mode = enums.ParseMode.DISABLED)
        
        # if (msgtl == 'x' or msgtl == 'ч') and msg.reply_to_message and msgr.entities:
        #     await msg.reply(f'`<emoji id={msgr.entities[0].custom_emoji_id}>{msgrt}</emoji>`', parse_mode = enums.ParseMode.MARKDOWN)
        
        ### Calculator ###
        if not re.findall(r'[а-яА-Я]', ''.join(msgtl.split('.к '))) and re.findall(r'\.к [-/\*)(\d+]+', msgtl):
            try:
                result = f'<i>Результат:</i> <code>{eval(msgtl.split(".к ")[1:][0])}</code>'
                temp = await app.send_message(entity, result)
            except (SyntaxError, OverflowError):
                asyncio.create_task(func.delete_msg(msg, delay = 3))
        
        if re.fullmatch(r'\.к \d+ \w+ \d+', msgtl):
            parts = msgtl.split(' ')
            await func.iris_calc(app ,msg, parts[2], parts[1], parts[3]); 
        
        elif re.fullmatch(r'\.д ((\d+\.\d|\d+)(k|к)|[\d\s]+) \d+', msgtl):
            await func.iris_calc_food(app, msg)
        
        elif re.fullmatch(r'\.д ((\d+\.\d|\d+)(k|к)|[\d\s]+) \d+ \w+ \d+', msgtl):
            await func.iris_calc_food_lvlup(app, msg)
        #
        
        # Спасибики при заражении
        if msgtl == '!thanks':
            if Settings.infect_thanks:
                temp = await msg.reply('❌ Спасибки при заражаении выключены')
                func.edit_cf(f_config, 'user_settings', 'infect_thanks', 'False')
            else:
                temp = await msg.reply('💖 Спасибки при заражаении включены')
                func.edit_cf(f_config, 'user_settings', 'infect_thanks', 'True')
            Settings.refresh(f_config)
            asyncio.create_task(func.delete_msg([msg, temp], delay = 12))
        
        if msgtl == '!reaction':
            if Settings.infect_reaction:
                temp = await msg.reply('❌ Реакции при заражаении выключены')
                func.edit_cf(f_config, 'user_settings', 'infect_reaction', 'False')
            else:
                temp = await msg.reply('💖 Реакции при заражаении включены')
                func.edit_cf(f_config, 'user_settings', 'infect_reaction', 'True')
            Settings.refresh(f_config)
            asyncio.create_task(func.delete_msg([msg, temp], delay = 12))
        
        if msgtl == '!рестарт':
            await msg.reply('<i><b>Юзербот перезапущен! 💯</b></i>', quote = False)
            func.restart_program()
        
        # грубые или милые ответы на где
        if re.fullmatch(r'!где (грубый|милый|рандом)', msgtl):
            mode = msgtl.split(' ')[1]
            
            temp = await msg.reply(f'Теперь я буду {mode} ✨', quote = False)
            func.edit_cf(f_config, 'user_settings', 'where_mode', mode)
            Settings.refresh(f_config)

        # визуальная запись жертв
        if msgtl == '!visual_victims':
            if Settings.visual_victims:
                temp = await msg.reply('❌ Визуальная запись жертв выключена')
                func.edit_cf(f_config, 'user_settings', 'visual_victims', 'False')
            else:
                temp = await msg.reply('💖 Визуальная запись жертв включена')
                func.edit_cf(f_config, 'user_settings', 'visual_victims', 'True')
            Settings.refresh(f_config)
            asyncio.create_task(func.delete_msg([msg, temp], delay = 12))



@app.on_message(filters.text & filters.user('me'), group = 9)
async def special_media(app: Client, msg: Message):
    
    msgt = msg.text
    msgtl = msg.text.lower()
    entity = msg.chat.id
    
    if msg.reply_to_message:
        msgr = msg.reply_to_message
        msgrt = msgr.text
    
    if msgtl == '.convert' and msg.reply_to_message and msgr.document and msgr.document.file_name == 'victims.json':
        
        temp_victims = await msgr.download()
        
        victims_dir = '/'.join(temp_victims.split('/')[:-1])
        new_victims_file = f'{victims_dir}/zarlistbackup.pickle'
        
        with open(temp_victims, 'r') as f:
            victims = json.load(f)
        
        victims_pickle = {}
        
        for key, val in victims.items():
            victims_pickle.setdefault('zar', {})[f'@{key}'] = [val['experience'], val['ot_data']]
        
        with open(new_victims_file, 'wb') as f:
            pickle.dump(victims_pickle, f)
        
        receiver_entity = f'<a href="tg://openmessage?user_id={msgr.from_user.id}">{msgr.from_user.first_name}</a>'
        
        await msgr.reply_document(document = new_victims_file, caption = f'Converted victims file scrooge > hikka, for {receiver_entity}')
        
        os.remove(temp_victims)
        os.remove(new_victims_file)
        await msg.delete()
        
        
        


# async def secret():
#     s = ''
#     async for msg in app.get_chat_history(1224690646):
#         s += f'{msg.from_user.first_name}: {msg.text}\n'
#     with open('finish.txt', 'w') as f:
#         f.write(s)


# async def secret():
#     if os.path.exists('finish.txt'):
#         os.remove('finish.txt')
#     if not os.path.exists('secret'):
#         os.mkdir('secret')
#     async for dialog in app.get_dialogs():
#         dia = ''
#         if dialog.chat.type == enums.ChatType.PRIVATE:
#             chatik = str(dialog.chat.first_name if dialog.chat.first_name else dialog.chat.id).replace('/', 'sl')
#             if not os.path.exists(f'secret/{chatik}'):
#                 os.mkdir(f'secret/{chatik}')
#             async for msg in app.get_chat_history(dialog.chat.id, limit = 200):
#                 if msg.text is not None:
#                     dia += f'{msg.from_user.first_name} {msg.text}\n\n'
#                 # if msg.media and msg.media != enums.MessageMediaType.WEB_PAGE:
#                 #     await msg.download(f'secret/{dialog.chat.id}/')
#             with open(f'secret/{chatik}/{dialog.chat.first_name}.txt', 'w') as f:
#                 f.write(dia)
#     with open('finish.txt', 'w') as f:
#         f.write('')

# asyncio.create_task(secret())

